odoo.define('export_button_access.ListController', function (require) {
"use strict";

var Sidebar = require('web.Sidebar');
var session = require('web.session');

Sidebar.include({
    /**
     * Override _redraw to hide export options from sidebar
     * @override
     */
    _redraw: function () {
        var self = this;
        var _super = this._super.bind(this);
        
        return session.user_has_group('export_button_access.group_export_data').then(function(has_group) {
            return _super.apply(self, arguments).then(function() {
                if (!has_group) {
                    // Hide export items from the sidebar/action menu
                    self.$('.o_sidebar_export').hide();
                    self.$el.find('a[data-section="other"]').each(function() {
                        var $link = $(this);
                        if ($link.text().trim() === 'Export' || $link.data('index') === 'export') {
                            $link.parent().hide();
                        }
                    });
                }
            });
        });
    },
});

});
