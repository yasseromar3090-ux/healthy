from odoo import api, fields, models
from odoo.exceptions import ValidationError


class Customer(models.Model):
    _inherit = 'res.partner'


    @api.constrains('mobile')
    def check_mobile(self):
        if self.mobile:
            if len(self.env['res.partner'].search([("mobile", "=", self.mobile)])) > 1:
                raise ValidationError("Mobile Number already exists")

    @api.constrains('phone')
    def check_phone(self):
        if self.phone:
            if len(self.env['res.partner'].search([("phone", "=", self.phone)])) > 1:
                raise ValidationError("Phone Number already exists")