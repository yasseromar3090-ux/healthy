from odoo import api, fields, models
from odoo.exceptions import ValidationError


class Customer(models.Model):
    _inherit = 'res.partner'


    @api.constrains('mobile','phone')
    def check_mobile(self):
        if self.mobile or self.phone:
            if len(self.env['res.partner'].search([("mobile", "in", [self.mobile,self.phone])])) > 1:
                raise ValidationError("Mobile Number already exists")
        if self.mobile or self.phone:
            if len(self.env['res.partner'].search([("phone", "in", [self.mobile,self.phone])])) > 1:
                raise ValidationError("Phone Number already exists")

